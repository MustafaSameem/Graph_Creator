public class Arun {
    int start;
    int length;
    Arun() {
        start =0;
        length=0;
    }

    //getters
    int getStart() {return start;}
    int getLength() {return length;}

    //setters
    void setStart(int s) {
        start =s;
    }
    void setLength(int l) {
        length =l;
    }
}
